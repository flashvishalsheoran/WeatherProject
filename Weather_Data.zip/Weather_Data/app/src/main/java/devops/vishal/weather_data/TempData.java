package devops.vishal.weather_data;

public class TempData {
    //String Variables to hold the values coming form server

    String dt;
    String day;
    String night;
    String eve;
    String morn;
    String min;
    String max;
    String description;



    //Parametrized Constructors

    public TempData(String dt, String day, String night, String eve, String morn, String min, String max, String description) {
        this.dt = dt;
        this.day = day;
        this.night = night;
        this.eve = eve;
        this.morn = morn;
        this.min = min;
        this.max = max;
        this.description = description;
    }



    //Setters and Getters

    public String getDt() {
        return dt;
    }

    public void setDt(String dt) {
        this.dt = dt;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getNight() {
        return night;
    }

    public void setNight(String night) {
        this.night = night;
    }

    public String getEve() {
        return eve;
    }

    public void setEve(String eve) {
        this.eve = eve;
    }

    public String getMorn() {
        return morn;
    }

    public void setMorn(String morn) {
        this.morn = morn;
    }

    public String getMin() {
        return min;
    }

    public void setMin(String min) {
        this.min = min;
    }

    public String getMax() {
        return max;
    }

    public void setMax(String max) {
        this.max = max;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


}
