package devops.vishal.weather_data;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class AdapterClass extends RecyclerView.Adapter<AdapterClass.ViewHolder> {

    private List<TempData> list_data;

    public AdapterClass(List<TempData> data) {
        this.list_data = data;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int i) {
        TempData Data=list_data.get(i);

        holder.dt.setText(Data.getDt());
        holder.day.setText(Data.getDay());
        holder.night.setText(Data.getNight());
        holder.eve.setText(Data.getEve());
        holder.morn.setText(Data.getMorn());
        holder.min.setText(Data.getMin());
        holder.max.setText(Data.getMax());
        holder.description.setText(Data.getDescription());



    }


    @Override
    public int getItemCount() {
        return list_data.size();
    }






    class ViewHolder extends RecyclerView.ViewHolder{

        public TextView dt;
        public TextView day;
        public TextView night;
        public TextView eve;
        public TextView morn;
        public TextView min;
        public TextView max;
        public TextView description;


        public ViewHolder(View itemView) {
            super(itemView);
            dt =  itemView.findViewById(R.id.date);
            day =  itemView.findViewById(R.id.temp);
            night =  itemView.findViewById(R.id.tempnight);
            eve =  itemView.findViewById(R.id.tempeve);
            morn =  itemView.findViewById(R.id.tempmorn);
            min =  itemView.findViewById(R.id.tempmin);
            max =  itemView.findViewById(R.id.tempmax);
            description =  itemView.findViewById(R.id.tempdesp);



        }

    }




}
