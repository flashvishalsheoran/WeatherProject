package devops.vishal.weather_data;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<TempData> list_data = new ArrayList<>();
    private RecyclerView recycler;
    private AdapterClass adapter;
    private TextView Longitide, Latitide, City_Name, Country;

    private String city_name,longitude,latitude,country;

    private String URl = "https://api.myjson.com/bins/xiv0c";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycler = findViewById(R.id.recycler_view);
        Longitide = (TextView) findViewById(R.id.lon);
        Latitide = (TextView) findViewById(R.id.lat);
        City_Name = (TextView) findViewById(R.id.name);
        Country = (TextView) findViewById(R.id.country);



        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter=new AdapterClass(list_data);


        StringRequest request = new StringRequest(Request.Method.GET, URl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    JSONObject obj = new JSONObject(response);
                    JSONObject city = obj.getJSONObject("city");
                    city_name = city.getString("name");

                    JSONObject longlat = city.getJSONObject("coord");
                    longitude = longlat.getString("lon");
                    latitude = longlat.getString("lat");




                    //Setting the TextView Items for the Page

                    City_Name.setText(city_name);
                    Longitide.setText(longitude);
                    Latitide.setText(latitude);





                    JSONArray lists = obj.getJSONArray("list");

                    for(int i=0; i<lists.length(); i++) {
                        JSONObject data = lists.getJSONObject(i);

                        String date = data.getString("dt");

                        JSONObject temperature = data.getJSONObject("temp");
                        String day = temperature.getString("day");
                        String night = temperature.getString("night");
                        String eve = temperature.getString("eve");
                        String morn = temperature.getString("morn");
                        String min = temperature.getString("min");
                        String max = temperature.getString("max");


                        JSONArray weather = data.getJSONArray("weather");
                        for(int j=0; j<weather.length(); j++){
                            JSONObject data1 = weather.getJSONObject(j);

                            String description = data1.getString("description");


                            //Uploading Class Objects in the List
                            TempData t = new TempData(date,day,night,eve,morn,min,max,description);
                            list_data.add(t);




                            //For Debugging Purposes only. This helps in Unit Testings

                            Log.d("/////Day////", date);
                            Log.d("/////Day////", day);
                            Log.d("/////Day////", night);
                            Log.d("/////Day////", eve);
                            Log.d("/////Day////", morn);
                            Log.d("/////Day////", min);
                            Log.d("/////Day////", max);
                            Log.d("/////Day////", description);

                        }





                    }



                    //Setting Adapter for Recylerview
                    recycler.setAdapter(adapter);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });



        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(request);









    }

}
